package com.demo.teja;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class HelloDemoApplicationTest {

	@Test
	void contextLoads() {
	}
}
